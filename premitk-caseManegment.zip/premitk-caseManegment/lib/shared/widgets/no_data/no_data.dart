// ignore_for_file: non_constant_identifier_names

import 'package:flutter/material.dart';

Widget NoData(context)=>const Image(image: AssetImage('images/no-data-icon-1.png'), fit: BoxFit.fill,);