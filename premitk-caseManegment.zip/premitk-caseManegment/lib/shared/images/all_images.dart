// @dart=2.9

// ignore_for_file: constant_identifier_names

const String loginImage = 'images/backGround.jpg';
const String splashScreenImg = 'images/splash.png';
const String splashScreenImg2 = 'images/startScreen.png';
const String UserInfoScreen = 'images/avatar.png';
const String UserInfoScreen3 = 'images/prfile2.png';
