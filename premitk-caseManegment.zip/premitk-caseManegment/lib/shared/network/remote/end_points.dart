// ignore_for_file: constant_identifier_names, non_constant_identifier_names, import_of_legacy_library_into_null_safe

// const BASE_URL = 'https://wowdesk.wowdesk.com/api/';
 import 'package:primitk_crm/shared/constants/constatnt.dart';

String  BASE_URL = 'http://$dOMAiN.qa.$dOMAiN.com/api/v2';




const SignIn = 'SignIn';
const GetUserViews = 'GetUserViews';
const RegisterNewCustomer = 'RegisterNewCustomer';
const GetAssignments = 'GetAssignments';
const GetStatuses = 'GetStatuses';
const SubmitNewCase = 'SubmitNewCase';
const GetCaseDetails = 'GetCaseDetails';

const UpdateCase = 'UpdateCase';
const GetCases = 'GetCases';
const GetTypes = 'GetTypes';
const GetSources = 'GetSources';
const GetProductGroups = 'GetProductGroups';
const GetProducts = 'GetProducts';
const GetCategories = 'GetCategories';
const GetSubCategories = 'GetSubCategories';
const GetCustomers = 'GetCustomers';
const GetCasesHistoryForCustomer = 'GetCasesHistoryForCustomer';
const GetCustomerDetails = 'GetCustomerDetails';
const GetPriorities = 'GetPriorities';
const GetIDTypes = 'GetIDTypes';
const GetCustomersBySearch = 'GetCustomersBySearch';
const AddNote = 'AddNote';
const UploadAttachment = 'UploadAttachment';




