
// @dart=2.9

// ignore_for_file: non_constant_identifier_names

String TOKEN ='';


String dOMAiN;





String UserName = '';
String ClientName = '';
String Name = '';
String Email = '';
String Phone = '';
String OrganizationUnit = '';
String DefaultFilter = '';
bool EnableNotifications ;