package com.example.primitk_crm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
